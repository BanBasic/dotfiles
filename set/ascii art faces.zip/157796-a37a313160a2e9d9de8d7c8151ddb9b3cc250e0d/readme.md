I guess font support is what matters, not OS, so I combined all the horizontal ones regardless of whether they work everywhere.  Paste at your own risk!

Assimilate these:
- http://www.reddit.com/tb/87kmx
- https://en.wikipedia.org/wiki/List_of_emoticons#Eastern
- http://www.unicode.org/charts/ (look for emoticons)
- https://en.wikipedia.org/wiki/Kaomoji (顔文字) [done]
- http://unicodeemoticons.com/howto.htm [done]
- http://superkawaiiemoticon.tumblr.com/post/21630699578/emoji-master-post [done]
- everything in the gist comments [done as of 2014-03-18]
